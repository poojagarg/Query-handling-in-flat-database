#include<stdio.h>

int main()
{
	char *a="Hello";
	char m=*a;
		printf("\n11%c11\n",m);
}
