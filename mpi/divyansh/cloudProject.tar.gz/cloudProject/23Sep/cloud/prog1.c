/* strstr example */
#include <stdio.h>
#include <string.h>

int main ()
{
  char str[];
  char * pch;

	gets(str);
  if(strstr (str,"not"))
{
	printf("----");
}
else
{
	printf("8888");
}
  return 0;
}
